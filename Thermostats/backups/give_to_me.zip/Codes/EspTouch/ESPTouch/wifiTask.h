#pragma once
#ifndef WIFITASK_H
#define WIFITASK_H

#include <Arduino.h>
#include <WiFi.h>
#include <Arduino_JSON.h>

#include "DataHandler.h"
#include "MyServer.h"
#include "JavaScript.h"

#define TITLE "ESPTouch"
#define TIMER_DELAY 1500

//javaScript span variables
#define ACTIVE_PROGRAM "active_prog"
#define WANTED_TEMP "wtmp"
#define TEMPERARTURE "temp"
#define HUMADITY "hmd"
#define SIMPLE_TAG "simple tag"
#define HEATINGCIRCLE_SWITCH "headting_"

//client websocket msg to main server, and not for refress its own server page
#define MAC_ADDRESS "mac"
#define WIFI_ID "id"
#define WIFI_HEATINGCIRCLE_ID "heating_id"
#define WIFI_DEVICE_NAME "name"

#define DEFAULT_TEMP 20.0


class wifiTask{

  MyServer *server;
  DataHandler *data;
  unsigned sensor_location;

  unsigned lastTime;
  unsigned timerDelay;
  bool function_selector;

  void init_html_page();
  void set_Json_messages();
  void client_server_activity_check();

  void set_active_prog(String);
  void set_wtmp(String);
  void set_temp(JSONVar);
  void set_mac(String,JSONVar);
  void proccess_received_data();

public:

  wifiTask(DataHandler *);
  ~wifiTask();

  void main();
};
#endif // WIFITASK