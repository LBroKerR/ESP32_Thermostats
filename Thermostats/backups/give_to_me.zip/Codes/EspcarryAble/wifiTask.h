#pragma once
#ifndef WIFITASK_H
#define WIFITASK_H

#include "DataHandler.h"
#include "MyServer.h"


class wifiTask{
  MyServer *server;
  DataHandler *data;

public:

  wifiTask(DataHandler *);
  ~wifiTask();
  void init_html_page();

  void main();
  
};
#endif // WIFITASK