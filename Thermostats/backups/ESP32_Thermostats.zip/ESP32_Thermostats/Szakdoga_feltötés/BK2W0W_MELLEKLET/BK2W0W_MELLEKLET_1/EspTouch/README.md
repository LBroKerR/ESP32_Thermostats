http://arduino.esp8266.com/stable/package_esp8266com_index.json 
https://raw.githubusercontent.com/espressif/arduino-esp32/gh-pages/package_esp32_index.json
-----------------------
Add to Arduino boardManager

https://www.silabs.com/documents/public/software/CP210x_Universal_Windows_Driver.zip
----------------------
CP2102 USB UART brigde -> install to get thinks work.

https://github.com/witnessmenow/ESP32-Cheap-Yellow-Display
----------------------
includes files only work with this hardware. Study this GitHub page before editing my work.


GUI- graphical user interface - design are created in Squarline studio. Code generetad here. Database and GUI connected by hand coding in main_task


