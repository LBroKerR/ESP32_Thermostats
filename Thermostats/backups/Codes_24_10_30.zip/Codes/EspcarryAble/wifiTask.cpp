#include "wifiTask.h"


wifiTask::wifiTask(DataHandler *obj){
    data=obj;
    server=new MyServer(data->get_wifi_data()->get_ssid(), data->get_wifi_data()->get_pass(), data->get_wifi_data()->get_host());
    lastTime=0;
    function_selector=false;
    timerDelay=TIMER_DELAY;
    init_html_page();
    server->Wifi_connection();
    server->Server_turning_on();
    server->connect_to_server(data->get_wifi_data()->get_ip());
}
wifiTask::~wifiTask(){
    delete server;
}
void wifiTask::init_html_page(){

    server->create_html_page(data->getSensor()->getNickName());
    server->get_Page()->add_tag(String(DEVICE_NAME), "Device name: ", "null");
    server->get_Page()->add_tag(String(MAC_ADDRESS), "Mac address: ", "null");
    server->get_Page()->add_tag(String(ID), "Device ID: ", "null");
    server->get_Page()->add_tag(String(HEATINGCIRCLE_ID), "Heating circle ID: ", "null");

    server->get_Page()->add_tag(String(TEMPERATURE)+String(data->getSensor()->getHeatingCircleID())+"_"+String(data->getSensor()->getID()), "Temperature: "," &deg;C");
    server->get_Page()->add_tag(String(HUMADITY)+String(data->getSensor()->getHeatingCircleID())+"_"+String(data->getSensor()->getID()), "Humadity: ", " %");
    server->get_Page()->add_tag(String(SIMPLE_TAG), "ESPTouch server link: ", "null");
    server->get_Page()->add_list_elem(data->get_wifi_data()->get_ip(),data->get_wifi_data()->get_ip());
    server->get_Page()->set_java_script(get_script());

}

void wifiTask::set_Json_messages(){
    //mac, name, heating_id, id ++
    server->set_JS_msg(String(MAC_ADDRESS),server->get_Mac());
    server->set_JS_msg(String(ID), String(data->getSensor()->getID()));
    server->set_JS_msg(String(HEATINGCIRCLE_ID), String(data->getSensor()->getHeatingCircleID()));
    server->set_JS_msg(String(DEVICE_NAME), data->getSensor()->getNickName());
    //humadity, temperature 
    server->set_JS_msg(String(TEMPERATURE)+String(data->getSensor()->getHeatingCircleID())+"_"+String(data->getSensor()->getID()),String(data->getSensor()->getMeasuredTemperature(),1));
    server->set_JS_msg(String(HUMADITY)+String(data->getSensor()->getHeatingCircleID())+"_"+String(data->getSensor()->getID()), String(data->getSensor()->getMeasureHmd()));
    //wtmp, active prog
    if(data->getProg()->get_active_program_index_changed()){
        server->set_JS_msg(String(ACTIVE_PROGRAM),String(data->getProg()->get_active_program_index()));
        data->getProg()->set_active_program_index_changed(false);
    }
    if(data->getProg()->get_wtmp_changed()){
        server->set_JS_msg(String(WANTED_TEMP),String(data->getProg()->get_Wanted_temp(),1));
        data->getProg()->set_wtmp_changed(false);
    }
}

void wifiTask::set_active_program(String str){
    if(str!=""){
        data->getProg()->set_program_index(str.toInt()-1);
    }
}
void wifiTask::set_wanted_temp(String str){
    if(str!=""){
        data->getProg()->set_wtmp(str.toFloat());
        data->getProg()->set_wtmp_changed(true);
    }
}
void wifiTask::set_heating_switch(String str){
    if(str!=""){
        if(str=="OFF"){
            data->setSwitch(false);
        }
        else if(str=="ON"){
            data->setSwitch(true);
        }
    }
}

void wifiTask::proccess_received_data(){
    //where is the client receive ? in handleWebSocketMessage or in onEvent1?
    //may be in onEvent1
    //active program, wtmp, headting_index of heatingcircle id
    if(server->get_received_data()!=nullptr){
        JSONVar msg;
        for(unsigned i=0; i< server->get_received_data()->size(); i++){
            if((server->get_received_data()->get_msg_array()==nullptr){
              return;
            }
            msg=JSON.parse(server->get_received_data()->get_msg_array()[i]);
            if(JSON.typeof(msg) != "undefined"){
                set_active_program(String((const char*)msg[ACTIVE_PROGRAM]));
                set_wanted_temp(String((const char*)msg[WANTED_TEMP]));
                set_heating_switch(String((const char*)msg[String(ACTIVE_PROGRAM)+String(data->getSensor()->getHeatingCircleID())]));
            }
            server->get_received_data()->remove_msg(i);
        }
    }
}

void wifiTask::main(){
  //receive time
  //send data if something changed
    if ((millis() - lastTime) > timerDelay) {
        set_Json_messages();
        server->updata();
        lastTime = millis();
    }
    if(!function_selector){
        proccess_received_data();
            //function_selector=true;
    }
    server->run_server();
}