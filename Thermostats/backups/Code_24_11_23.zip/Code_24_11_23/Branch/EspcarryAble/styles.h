#pragma once
#ifndef STYLES_H
#define STYLES_H

#include <Arduino.h>

String get_styles();

#endif //STYLES_H