#include "wifiTask.h"


wifiTask::wifiTask(DataHandler *obj){
    data=obj;
    server=new MyServer(data->get_wifi_data()->get_ssid(), data->get_wifi_data()->get_pass(), data->get_wifi_data()->get_host());
    server->Wifi_connection();
    init_html_page();
    server->Server_turning_on();
    server->connect_to_server(data->get_wifi_data()->get_ip());
}
wifiTask::~wifiTask(){
    delete server;
}
void wifiTask::init_html_page(){

}

void wifiTask::main(){

}