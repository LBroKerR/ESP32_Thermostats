# TO DO:
    - Flag bool vars change to mutex vars!!