#pragma once
#ifndef JAVASCRIPT_H
#define JAVASCRIPT_H

#include <Arduino.h>

String get_script(String);

#endif //JAVASCRIPT_H