#include "JSON_message.h"

JSON_message::JSON_message(){
    msg=nullptr;
    number_of_msg=0;
}
JSON_message::~JSON_message(){
    if(msg!=nullptr){
        delete[] msg;
    }
}
void JSON_message::add_msg(String str){
    if(msg==nullptr || number_of_msg==0){
        delete[] msg;
        number_of_msg=0;
    }
    String*tmp=new String[number_of_msg+1];
    for (unsigned i = 0; i < number_of_msg; i++){
        tmp[i]=msg[i];
    }
    tmp[number_of_msg]=str;
    delete msg;
    msg=tmp;
    number_of_msg++;
}
void JSON_message::remove_msg(unsigned index){
    if(msg==nullptr || number_of_msg==0){
        delete[] msg;
        number_of_msg=0;
        return;
    }
    if(index> number_of_msg){
        return;
    }
    String*tmp=new String[number_of_msg-1];
    for(unsigned i=0; i<number_of_msg-1; i++){
        if(i<index){
            tmp[i]=msg[i];
        }
        else if(i>=index){
            tmp[i]=msg[i+1];
        }
    }
    delete[] msg;
    msg=tmp;
    number_of_msg--;

}

String * JSON_message::get_msg_array(){
    return msg;
}
String  JSON_message::get_msg(unsigned i){
    return msg[i];
}
unsigned JSON_message::size()const{
  return number_of_msg;
}